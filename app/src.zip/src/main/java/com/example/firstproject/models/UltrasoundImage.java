package com.example.firstproject.models;

import java.util.Date;

public class UltrasoundImage {
    private long id;
    private long pregnancyId;
    private String imageUri;
    private Date imageDate;
    private String notes;
    private int pregnancyWeek;

    public UltrasoundImage() {
        this.imageDate = new Date();
    }

    public UltrasoundImage(long pregnancyId, String imageUri, String notes, int pregnancyWeek) {
        this.pregnancyId = pregnancyId;
        this.imageUri = imageUri;
        this.notes = notes;
        this.pregnancyWeek = pregnancyWeek;
        this.imageDate = new Date();
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public long getPregnancyId() {
        return pregnancyId;
    }

    public void setPregnancyId(long pregnancyId) {
        this.pregnancyId = pregnancyId;
    }

    public String getImageUri() {
        return imageUri;
    }

    public void setImageUri(String imageUri) {
        this.imageUri = imageUri;
    }

    public Date getImageDate() {
        return imageDate;
    }

    public void setImageDate(Date imageDate) {
        this.imageDate = imageDate;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    public int getPregnancyWeek() {
        return pregnancyWeek;
    }

    public void setPregnancyWeek(int pregnancyWeek) {
        this.pregnancyWeek = pregnancyWeek;
    }
}
