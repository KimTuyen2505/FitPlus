package com.example.firstproject.models;

import java.util.Date;

public class PregnancyData {
    private long id;
    private long userId;
    private Date lastPeriodDate;
    private Date dueDate;
    private String babyName;
    private boolean isConfirmed;
    private Date confirmationDate;

    public PregnancyData() {
        this.confirmationDate = new Date();
        this.isConfirmed = false;
    }

    public PregnancyData(long userId, Date lastPeriodDate, String babyName) {
        this.userId = userId;
        this.lastPeriodDate = lastPeriodDate;
        this.babyName = babyName;
        this.confirmationDate = new Date();
        this.isConfirmed = true;
        calculateDueDate();
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public long getUserId() {
        return userId;
    }

    public void setUserId(long userId) {
        this.userId = userId;
    }

    public Date getLastPeriodDate() {
        return lastPeriodDate;
    }

    public void setLastPeriodDate(Date lastPeriodDate) {
        this.lastPeriodDate = lastPeriodDate;
        calculateDueDate();
    }

    public Date getDueDate() {
        return dueDate;
    }

    public void setDueDate(Date dueDate) {
        this.dueDate = dueDate;
    }

    public String getBabyName() {
        return babyName;
    }

    public void setBabyName(String babyName) {
        this.babyName = babyName;
    }

    public boolean isConfirmed() {
        return isConfirmed;
    }

    public void setConfirmed(boolean confirmed) {
        isConfirmed = confirmed;
    }

    public Date getConfirmationDate() {
        return confirmationDate;
    }

    public void setConfirmationDate(Date confirmationDate) {
        this.confirmationDate = confirmationDate;
    }

    // Calculate due date (280 days from last period date)
    private void calculateDueDate() {
        if (lastPeriodDate != null) {
            long dueTime = lastPeriodDate.getTime() + (280L * 24 * 60 * 60 * 1000);
            this.dueDate = new Date(dueTime);
        }
    }

    // Calculate current pregnancy week
    public int getCurrentWeek() {
        if (lastPeriodDate == null) {
            return 0;
        }

        long diffInMillis = System.currentTimeMillis() - lastPeriodDate.getTime();
        int days = (int) (diffInMillis / (1000 * 60 * 60 * 24));
        return days / 7;
    }

    // Calculate days of pregnancy
    public int getDaysOfPregnancy() {
        if (lastPeriodDate == null) {
            return 0;
        }

        long diffInMillis = System.currentTimeMillis() - lastPeriodDate.getTime();
        return (int) (diffInMillis / (1000 * 60 * 60 * 24));
    }

    // Get remaining days until due date
    public int getRemainingDays() {
        if (dueDate == null) {
            return 0;
        }

        long diffInMillis = dueDate.getTime() - System.currentTimeMillis();
        return (int) (diffInMillis / (1000 * 60 * 60 * 24));
    }
}
